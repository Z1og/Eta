//go:build android

package main

// Install Android's system dnsproxyd resolver for the CGO-disabled binary.
// The pure-Go default reads /etc/resolv.conf, which Android does not supply.
// Use the same DNS configuration (including Private DNS and VPN routing)
// as the host Android app.
import _ "opencode2api/internal/androiddns"
